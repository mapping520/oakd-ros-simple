#pragma once

#include <string>

namespace dai
{
namespace utility
{

std::string getEnv(const std::string& var);

} // namespace utility
} // namespace dai
