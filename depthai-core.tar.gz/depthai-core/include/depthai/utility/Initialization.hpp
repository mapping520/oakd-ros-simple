#pragma once

#include <string>

namespace dai {

bool initialize(std::string additionalInfo = "", bool installSignalHandler = true);

}  // namespace dai
