//-------------------------------------------------------------------
//  Nano RPC
//  https://github.com/tdv/nanorpc
//  Created:     06.2018
//  Copyright (C) 2018 tdv
//-------------------------------------------------------------------

#ifndef __NANO_RPC_CORE_DETAIL_CONFIG_H__
#define __NANO_RPC_CORE_DETAIL_CONFIG_H__


#define NANORPC_PURE_CORE

#endif	// !__NANO_RPC_CORE_DETAIL_CONFIG_H__
