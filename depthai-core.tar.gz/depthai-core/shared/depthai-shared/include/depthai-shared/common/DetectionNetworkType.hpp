#pragma once

#include <cstdint>

enum class DetectionNetworkType : std::int32_t { YOLO, MOBILENET };
